// Auto-generated. Do not edit!

// (in-package my_serialport.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ImuCar {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.imu_car_quaternary_w = null;
      this.imu_car_quaternary_x = null;
      this.imu_car_quaternary_y = null;
      this.imu_car_quaternary_z = null;
      this.imu_car_yaw = null;
    }
    else {
      if (initObj.hasOwnProperty('imu_car_quaternary_w')) {
        this.imu_car_quaternary_w = initObj.imu_car_quaternary_w
      }
      else {
        this.imu_car_quaternary_w = 0.0;
      }
      if (initObj.hasOwnProperty('imu_car_quaternary_x')) {
        this.imu_car_quaternary_x = initObj.imu_car_quaternary_x
      }
      else {
        this.imu_car_quaternary_x = 0.0;
      }
      if (initObj.hasOwnProperty('imu_car_quaternary_y')) {
        this.imu_car_quaternary_y = initObj.imu_car_quaternary_y
      }
      else {
        this.imu_car_quaternary_y = 0.0;
      }
      if (initObj.hasOwnProperty('imu_car_quaternary_z')) {
        this.imu_car_quaternary_z = initObj.imu_car_quaternary_z
      }
      else {
        this.imu_car_quaternary_z = 0.0;
      }
      if (initObj.hasOwnProperty('imu_car_yaw')) {
        this.imu_car_yaw = initObj.imu_car_yaw
      }
      else {
        this.imu_car_yaw = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ImuCar
    // Serialize message field [imu_car_quaternary_w]
    bufferOffset = _serializer.float32(obj.imu_car_quaternary_w, buffer, bufferOffset);
    // Serialize message field [imu_car_quaternary_x]
    bufferOffset = _serializer.float32(obj.imu_car_quaternary_x, buffer, bufferOffset);
    // Serialize message field [imu_car_quaternary_y]
    bufferOffset = _serializer.float32(obj.imu_car_quaternary_y, buffer, bufferOffset);
    // Serialize message field [imu_car_quaternary_z]
    bufferOffset = _serializer.float32(obj.imu_car_quaternary_z, buffer, bufferOffset);
    // Serialize message field [imu_car_yaw]
    bufferOffset = _serializer.float32(obj.imu_car_yaw, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ImuCar
    let len;
    let data = new ImuCar(null);
    // Deserialize message field [imu_car_quaternary_w]
    data.imu_car_quaternary_w = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [imu_car_quaternary_x]
    data.imu_car_quaternary_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [imu_car_quaternary_y]
    data.imu_car_quaternary_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [imu_car_quaternary_z]
    data.imu_car_quaternary_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [imu_car_yaw]
    data.imu_car_yaw = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'my_serialport/ImuCar';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1f150c9a2e0062fb4b0b162be56d0f7f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 imu_car_quaternary_w
    float32 imu_car_quaternary_x
    float32 imu_car_quaternary_y
    float32 imu_car_quaternary_z
    float32 imu_car_yaw
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ImuCar(null);
    if (msg.imu_car_quaternary_w !== undefined) {
      resolved.imu_car_quaternary_w = msg.imu_car_quaternary_w;
    }
    else {
      resolved.imu_car_quaternary_w = 0.0
    }

    if (msg.imu_car_quaternary_x !== undefined) {
      resolved.imu_car_quaternary_x = msg.imu_car_quaternary_x;
    }
    else {
      resolved.imu_car_quaternary_x = 0.0
    }

    if (msg.imu_car_quaternary_y !== undefined) {
      resolved.imu_car_quaternary_y = msg.imu_car_quaternary_y;
    }
    else {
      resolved.imu_car_quaternary_y = 0.0
    }

    if (msg.imu_car_quaternary_z !== undefined) {
      resolved.imu_car_quaternary_z = msg.imu_car_quaternary_z;
    }
    else {
      resolved.imu_car_quaternary_z = 0.0
    }

    if (msg.imu_car_yaw !== undefined) {
      resolved.imu_car_yaw = msg.imu_car_yaw;
    }
    else {
      resolved.imu_car_yaw = 0.0
    }

    return resolved;
    }
};

module.exports = ImuCar;
