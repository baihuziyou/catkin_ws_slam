// Auto-generated. Do not edit!

// (in-package my_serialport.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class VelocityCar {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.VelocityCar = null;
      this.VelocityCar_x = null;
      this.VelocityCar_y = null;
      this.VelocityCar_w = null;
      this.QuaternionCar_w = null;
      this.QuaternionCar_x = null;
      this.QuaternionCar_y = null;
      this.QuaternionCar_z = null;
      this.CarYaw = null;
    }
    else {
      if (initObj.hasOwnProperty('VelocityCar')) {
        this.VelocityCar = initObj.VelocityCar
      }
      else {
        this.VelocityCar = 0.0;
      }
      if (initObj.hasOwnProperty('VelocityCar_x')) {
        this.VelocityCar_x = initObj.VelocityCar_x
      }
      else {
        this.VelocityCar_x = 0.0;
      }
      if (initObj.hasOwnProperty('VelocityCar_y')) {
        this.VelocityCar_y = initObj.VelocityCar_y
      }
      else {
        this.VelocityCar_y = 0.0;
      }
      if (initObj.hasOwnProperty('VelocityCar_w')) {
        this.VelocityCar_w = initObj.VelocityCar_w
      }
      else {
        this.VelocityCar_w = 0.0;
      }
      if (initObj.hasOwnProperty('QuaternionCar_w')) {
        this.QuaternionCar_w = initObj.QuaternionCar_w
      }
      else {
        this.QuaternionCar_w = 0.0;
      }
      if (initObj.hasOwnProperty('QuaternionCar_x')) {
        this.QuaternionCar_x = initObj.QuaternionCar_x
      }
      else {
        this.QuaternionCar_x = 0.0;
      }
      if (initObj.hasOwnProperty('QuaternionCar_y')) {
        this.QuaternionCar_y = initObj.QuaternionCar_y
      }
      else {
        this.QuaternionCar_y = 0.0;
      }
      if (initObj.hasOwnProperty('QuaternionCar_z')) {
        this.QuaternionCar_z = initObj.QuaternionCar_z
      }
      else {
        this.QuaternionCar_z = 0.0;
      }
      if (initObj.hasOwnProperty('CarYaw')) {
        this.CarYaw = initObj.CarYaw
      }
      else {
        this.CarYaw = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type VelocityCar
    // Serialize message field [VelocityCar]
    bufferOffset = _serializer.float32(obj.VelocityCar, buffer, bufferOffset);
    // Serialize message field [VelocityCar_x]
    bufferOffset = _serializer.float32(obj.VelocityCar_x, buffer, bufferOffset);
    // Serialize message field [VelocityCar_y]
    bufferOffset = _serializer.float32(obj.VelocityCar_y, buffer, bufferOffset);
    // Serialize message field [VelocityCar_w]
    bufferOffset = _serializer.float32(obj.VelocityCar_w, buffer, bufferOffset);
    // Serialize message field [QuaternionCar_w]
    bufferOffset = _serializer.float32(obj.QuaternionCar_w, buffer, bufferOffset);
    // Serialize message field [QuaternionCar_x]
    bufferOffset = _serializer.float32(obj.QuaternionCar_x, buffer, bufferOffset);
    // Serialize message field [QuaternionCar_y]
    bufferOffset = _serializer.float32(obj.QuaternionCar_y, buffer, bufferOffset);
    // Serialize message field [QuaternionCar_z]
    bufferOffset = _serializer.float32(obj.QuaternionCar_z, buffer, bufferOffset);
    // Serialize message field [CarYaw]
    bufferOffset = _serializer.float32(obj.CarYaw, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type VelocityCar
    let len;
    let data = new VelocityCar(null);
    // Deserialize message field [VelocityCar]
    data.VelocityCar = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [VelocityCar_x]
    data.VelocityCar_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [VelocityCar_y]
    data.VelocityCar_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [VelocityCar_w]
    data.VelocityCar_w = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [QuaternionCar_w]
    data.QuaternionCar_w = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [QuaternionCar_x]
    data.QuaternionCar_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [QuaternionCar_y]
    data.QuaternionCar_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [QuaternionCar_z]
    data.QuaternionCar_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [CarYaw]
    data.CarYaw = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 36;
  }

  static datatype() {
    // Returns string type for a message object
    return 'my_serialport/VelocityCar';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '04dd1ee39462e5778522330bb2af3daf';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 VelocityCar
    float32 VelocityCar_x
    float32 VelocityCar_y
    float32 VelocityCar_w
    float32 QuaternionCar_w
    float32 QuaternionCar_x
    float32 QuaternionCar_y
    float32 QuaternionCar_z
    float32 CarYaw
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new VelocityCar(null);
    if (msg.VelocityCar !== undefined) {
      resolved.VelocityCar = msg.VelocityCar;
    }
    else {
      resolved.VelocityCar = 0.0
    }

    if (msg.VelocityCar_x !== undefined) {
      resolved.VelocityCar_x = msg.VelocityCar_x;
    }
    else {
      resolved.VelocityCar_x = 0.0
    }

    if (msg.VelocityCar_y !== undefined) {
      resolved.VelocityCar_y = msg.VelocityCar_y;
    }
    else {
      resolved.VelocityCar_y = 0.0
    }

    if (msg.VelocityCar_w !== undefined) {
      resolved.VelocityCar_w = msg.VelocityCar_w;
    }
    else {
      resolved.VelocityCar_w = 0.0
    }

    if (msg.QuaternionCar_w !== undefined) {
      resolved.QuaternionCar_w = msg.QuaternionCar_w;
    }
    else {
      resolved.QuaternionCar_w = 0.0
    }

    if (msg.QuaternionCar_x !== undefined) {
      resolved.QuaternionCar_x = msg.QuaternionCar_x;
    }
    else {
      resolved.QuaternionCar_x = 0.0
    }

    if (msg.QuaternionCar_y !== undefined) {
      resolved.QuaternionCar_y = msg.QuaternionCar_y;
    }
    else {
      resolved.QuaternionCar_y = 0.0
    }

    if (msg.QuaternionCar_z !== undefined) {
      resolved.QuaternionCar_z = msg.QuaternionCar_z;
    }
    else {
      resolved.QuaternionCar_z = 0.0
    }

    if (msg.CarYaw !== undefined) {
      resolved.CarYaw = msg.CarYaw;
    }
    else {
      resolved.CarYaw = 0.0
    }

    return resolved;
    }
};

module.exports = VelocityCar;
