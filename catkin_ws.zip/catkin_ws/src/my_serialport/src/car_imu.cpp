#include <ros/ros.h>
#include <serial/serial.h>
#include <std_msgs/String.h>
#include <geometry_msgs/Twist.h> //cmd_vel在这个库文件里面
#include <std_msgs/Empty.h>
#include <sstream>
#include <nav_msgs/Odometry.h>
#include <tf/transform_broadcaster.h>  //从Z轴转角到四元数函数需要头文件
#include "tf2_ros/transform_broadcaster.h"  //发布动态的坐标关系。
#include <math.h> 
#include "ImuCar.h"

/*  说明
    从imu中接受数据,并使用自定义的msg组织imu数据欧拉角和偏航角
    向话题名 TopicImuCar 中发布数据
*/


#define SerilaPortName "/dev/usb_imu"      //串口端口名
#define SerilaPortBaudrate 9600            //波特率
#define CarVelocity 150
#define CarTurnVelocity 100

serial::Serial serialport_imu; //定义自己的串口



int main(int argc, char **argv)
{
    // setlocale(LC_CTYPE, "zh_CN.utf8"); //中文不乱码

    //初始化节点
    ros::init(argc, argv, "car_imu_node");
    //声明节点句柄
    ros::NodeHandle nh;

    ros::Publisher Imu_publisher = nh.advertise<my_serialport::ImuCar>("TopicImuCar", 1000);   //Imu数据发布

    // 设置发布话题频率
    ros::Rate loop_rate(10); //不是时间，是频率,代表1秒5次的速度发布或者调用回调函数，5hz



    //设置串口参数并打开串口

    try
    {
        serial::Timeout my_serialtimeout = serial::Timeout::simpleTimeout(1000); //设置超时时间1000ms.Timeout是一个结构体，设置超市时间的时候需要取址
        serialport_imu.setPort(SerilaPortName);          //串口端口
        serialport_imu.setBaudrate(SerilaPortBaudrate);            //波特率为115200
        serialport_imu.setParity(serial::parity_none); //无奇偶校验
        serialport_imu.setBytesize(serial::eightbits); //设置数据为为八位;
        serialport_imu.setTimeout(my_serialtimeout);
        serialport_imu.open();
    }

    catch (const std::exception &e)
    {
        // ROS_INFO_STREAM("can't openserialport");  //终端显示信息
        ROS_ERROR_STREAM("can't openserialport"); //使用红色的字体显示无法打卡串口
    }


    double car_row_Roll;
    double car_row_Pitch;
    double car_row_Yaw;

    double car_qua_w;
    double car_qua_x;
    double car_qua_y;
    double car_qua_z;

    uint8_t unlock[5] = {0xff, 0xaa, 0x69, 0x88, 0xb5};
    uint8_t setzero[5] = {0xff, 0xaa, 0x01, 0x08, 0x00};

    //imu置零
    serialport_imu.write(unlock, 5);
    ros::Duration(0.1).sleep();     //延时0,1秒
    serialport_imu.write(setzero, 5);
    ros::Duration(0.1).sleep();     //延时0,1秒

    // Imu数据类型
    my_serialport::ImuCar ImuDate;

    while (ros::ok())
    {
        

        // 读取IMU传感器的欧拉角
        size_t receivenumber = serialport_imu.available(); //获取缓冲区接受到的数据大小
        uint8_t buffer[1024];
        if (receivenumber != 0)
        {
            receivenumber = serialport_imu.read(buffer, receivenumber);  //把读取到的数据以字节的方式存放到buffer中
            for (int i = 0; i < receivenumber; i++)
            {
                if (buffer[i] == 0x55 && buffer[i + 1] == 0x53)
                {
                    // ROS_INFO("get the imu date");
                    car_row_Roll = (double)((short)(((short)(buffer[i + 3]) << 8 | buffer[i + 2]))) / 32768 * 180;
                    car_row_Pitch = (double)((short)(((short)(buffer[i + 5]) << 8 | buffer[i + 4]))) / 32768 * 180;
                    car_row_Yaw = (double)((short)(((short)(buffer[i + 7]) << 8 | buffer[i + 6]))) / 32768 * 180;
                    // ROS_INFO("Yaw:%f.",car_row_Yaw);
                }

                if(buffer[i]== 0x55 && buffer[i+1]== 0x59)
                {

                    car_qua_w = (double)((short)(((short)(buffer[i + 3]) << 8 | buffer[i + 2]))) / 32768;
                    car_qua_x = (double)((short)(((short)(buffer[i + 5]) << 8 | buffer[i + 4]))) / 32768;
                    car_qua_y = -1 * (double)((short)(((short)(buffer[i + 7]) << 8 | buffer[i + 6]))) / 32768;
                    car_qua_z = (double)((short)(((short)(buffer[i + 9]) << 8 | buffer[i + 8]))) / 32768;

                    // ROS_INFO("W:%f,X:%f,Y:%f,Z:%f", car_qua_w,car_qua_x,car_qua_y,car_qua_z);
                }
            }
        }

        //IMU数据组织
        ImuDate.imu_car_quaternary_w = car_qua_w;
        ImuDate.imu_car_quaternary_x = car_qua_x;
        ImuDate.imu_car_quaternary_y = car_qua_y;
        ImuDate.imu_car_quaternary_z = car_qua_z;

        //结局imu数据从180跳到-180的问题
        if(car_row_Yaw < 0)
        {
            ImuDate.imu_car_yaw = 180 + (180 + car_row_Yaw);
        }
        else
        {
            ImuDate.imu_car_yaw = car_row_Yaw;
        }

        
        
        //imu数据发布
        Imu_publisher.publish(ImuDate);

        ros::spinOnce();   //调用回调函数
        loop_rate.sleep(); //等待设定时间到达
    }
}
