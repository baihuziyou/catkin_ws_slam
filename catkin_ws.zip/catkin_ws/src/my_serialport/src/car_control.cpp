#include <ros/ros.h>
#include <serial/serial.h>
#include <std_msgs/String.h>
#include <geometry_msgs/Twist.h> //cmd_vel在这个库文件里面
#include <std_msgs/Empty.h>
#include <sstream>
#include <nav_msgs/Odometry.h>
#include <tf/transform_broadcaster.h>  //从Z轴转角到四元数函数需要头文件
#include "tf2_ros/transform_broadcaster.h"  //发布动态的坐标关系。
#include <math.h>
#include <VelocityCar.h>
#include <ImuCar.h>

/*
            car_velocity.cpp
    0.注意波特率是115200
    1.用于获取速度,
    2.根据cmd_vel发送控制指令
*/

//几个宏定义,CarCrossDistance:两个轮胎之间的距离,车宽度; WheelRadios:车轮半径

#define SerilaPortName "/dev/usb_motor"      //串口端口名
#define SerilaPortBaudrate 115200            //波特率
#define WheelRadios 0.18   
#define CarCrossDistance 1.440

//自定义的速度类型定义
my_serialport::VelocityCar VelocityCar;
serial::Serial serialport_control; //定义自己的串口

void carvelocityCallback(const geometry_msgs::Twist::ConstPtr &msg) 
{
    //cmd_vel中x,y,z是单位是m/s,角度是rad/s
    std_msgs::String transportdate;
    std::stringstream ss; //用于实现字符串拼接
    double left_motor_velocity = 0;  //左路角速度:rad/s
    double right_motor_velocity = 0; //右轮角速度:rad/s
    // ROS_INFO("%f", msg->linear.x); //这些数据是float类型的，不能用%d显示，会出错。

    left_motor_velocity = -1 * (msg->linear.x - msg->angular.z * CarCrossDistance / 2) / 0.18 * 24 * 9.55 / 1.5;
    right_motor_velocity = -1 * (msg->linear.x + msg->angular.z * CarCrossDistance / 2) / 0.18 * 24 * 9.55 / 1.5;
    //检查串口是否打开了
    if (serialport_control.isOpen())
    {
            // ss << "!M " << 200 << " " << 200 << "\r\n";
            ss << "!M " << right_motor_velocity << " " << left_motor_velocity << "\r\n"; //角速度乘半径为速度,24为传动比,计算出电机因该转动几度
            // ss << "!M " << 100 << " " << 100 << "\r\n"; //角速度乘半径为速度,24为传动比,计算出电机因该转动几度
            transportdate.data = ss.str();
            ROS_INFO("%s", transportdate.data.c_str());
            serialport_control.write(transportdate.data);
    }
    else
    {
        try
        {
            serialport_control.open();
            ROS_INFO_STREAM(SerilaPortName);
        }
        catch (const std::exception &e)
        {
            ROS_ERROR_STREAM("cat't open serialports  ");
        }
    }
}





int main(int argc, char **argv)
{
    setlocale(LC_CTYPE, "zh_CN.utf8"); //中文不乱码

    //初始化节点
    ros::init(argc, argv, "car_control_node");
    //声明节点句柄
    ros::NodeHandle nh;
    

    ros::Publisher odom_publisher = nh.advertise<my_serialport::VelocityCar>("TopicVelocity", 1000);
    //订阅话题
    ros::Subscriber car_velocity_sub = nh.subscribe("/cmd_vel", 1000, carvelocityCallback);
    ros::Rate loop_rate(10); //不是时间，是频率,代表1秒5次的速度发布或者调用回调函数，5hz



    try
    {
        serial::Timeout my_serialtimeout = serial::Timeout::simpleTimeout(1000); //设置超时时间1000ms.Timeout是一个结构体，设置超市时间的时候需要取址
        serialport_control.setPort(SerilaPortName);          //串口端口
        serialport_control.setBaudrate(SerilaPortBaudrate);            //波特率为115200
        serialport_control.setParity(serial::parity_none); //无奇偶校验
        serialport_control.setBytesize(serial::eightbits); //设置数据为为八位;
        serialport_control.setTimeout(my_serialtimeout);
        serialport_control.open();
        ROS_INFO_STREAM("open control_serial_port");
    }

    catch (const std::exception &e)
    {
        // ROS_INFO_STREAM("can't openserialport");  //终端显示信息
        ROS_ERROR_STREAM("can't openserialport"); //使用红色的字体显示无法打卡串口
    }

    while(ros::ok())
    {
        ros::spinOnce();
        loop_rate.sleep();
    }
}