#include <ros/ros.h>
#include <serial/serial.h>
#include <std_msgs/String.h>
#include <geometry_msgs/Twist.h> //cmd_vel在这个库文件里面
#include <std_msgs/Empty.h>
#include <sstream>
#include <nav_msgs/Odometry.h>
#include <tf/transform_broadcaster.h>  //从Z轴转角到四元数函数需要头文件
#include "tf2_ros/transform_broadcaster.h"  //发布动态的坐标关系。
#include <math.h>
#include <VelocityCar.h>
#include <ImuCar.h>

/*
            car_velocity.cpp
    0.注意波特率是115200
    1.用于获取速度,
    2.根据cmd_vel发送控制指令
*/

//几个宏定义,CarCrossDistance:两个轮胎之间的距离,车宽度; WheelRadios:车轮半径

#define SerilaPortName "/dev/usb_motor"      //串口端口名
#define SerilaPortBaudrate 115200            //波特率
#define WheelRadios 0.18
#define CarCrossDistance 1.440

//自定义的速度类型定义
my_serialport::VelocityCar VelocityCar;
serial::Serial serialport_velocity; //定义自己的串口


void ImuCarCallBack(const my_serialport::ImuCar::ConstPtr& ImuCarDate)
{
    ROS_INFO("Yaw:%f", ImuCarDate->imu_car_yaw);
    VelocityCar.VelocityCar_x = VelocityCar.VelocityCar * cosf(ImuCarDate->imu_car_yaw * 0.017453);
    VelocityCar.VelocityCar_y = VelocityCar.VelocityCar * sinf(ImuCarDate->imu_car_yaw * 0.017453);
    VelocityCar.QuaternionCar_w = ImuCarDate->imu_car_quaternary_w;
    VelocityCar.QuaternionCar_x = ImuCarDate->imu_car_quaternary_x;
    VelocityCar.QuaternionCar_y = ImuCarDate->imu_car_quaternary_y;
    VelocityCar.QuaternionCar_z = ImuCarDate->imu_car_quaternary_z;
    VelocityCar.CarYaw = ImuCarDate->imu_car_yaw;     //角度为单位
}

int main(int argc, char **argv)
{
    setlocale(LC_CTYPE, "zh_CN.utf8"); //中文不乱码

    //初始化节点
    ros::init(argc, argv, "car_velocity_node");
    //声明节点句柄
    ros::NodeHandle nh;
    
    ros::Subscriber car_imu_subscriber = nh.subscribe("TopicImuCar", 1000, ImuCarCallBack);


    ros::Publisher odom_publisher = nh.advertise<my_serialport::VelocityCar>("TopicVelocity", 1000);
    //订阅话题
    // ros::Subscriber car_velocity_sub = nh.subscribe("/cmd_vel", 1000, carvelocityCallback);

    // 设置发布话题频率
    ros::Rate loop_rate(10); //不是时间，是频率,代表1秒5次的速度发布或者调用回调函数，5hz

    std_msgs::String get_car_speed; //?S
    
    int car_leftwheel_motor_w = 0;
    int car_rightwheel_motor_w = 0;
    float car_leftwheel_velocity = 0;       //左右轮线速度
    float car_rightwheel_velocity = 0;




    try
    {
        serial::Timeout my_serialtimeout = serial::Timeout::simpleTimeout(1000); //设置超时时间1000ms.Timeout是一个结构体，设置超市时间的时候需要取址
        serialport_velocity.setPort(SerilaPortName);          //串口端口
        serialport_velocity.setBaudrate(SerilaPortBaudrate);            //波特率为115200
        serialport_velocity.setParity(serial::parity_none); //无奇偶校验
        serialport_velocity.setBytesize(serial::eightbits); //设置数据为为八位;
        serialport_velocity.setTimeout(my_serialtimeout);
        serialport_velocity.open();
        ROS_INFO_STREAM("速度的串口打开了");
    }

    catch (const std::exception &e)
    {
        // ROS_INFO_STREAM("can't openserialport");  //终端显示信息
        ROS_ERROR_STREAM("can't openserialport"); //使用红色的字体显示无法打卡串口
    }




    while (ros::ok())
    {
        serialport_velocity.write("?S\r\n");

        //读取控制器传输过来的速度信息,并解算出角速度信息;赋值给car_leftwheel_motor_w,和car_rightwheel_motor_w
        // !M 100 100:
        // 第一个是代表右轮的速度,前驱. 发送100会往后走,角速度返回的值是负的; !M 100 0 ; ?S = -147 0
        // 第二个是代表左轮的速度,前驱, 发送100会往后走,角速度返回的值是正的; !M 0 100 ; ?S =  0  147
        size_t receivenumber = serialport_velocity.available(); //获取缓冲区接受到的数据大小
        uint8_t buffer[1024];
        //从接受缓存中得到电机速度信息
        // ROS_INFO("速度串口看看有没有进去:有几个%d",receivenumber);
        if (receivenumber != 0)
        {
           
            // ROS_INFO("进来了");
            receivenumber = serialport_velocity.read(buffer, receivenumber);
            int left_velocityBit = 0; //判断左轮速度占用几位
            int right_velocityBit = 0; //判断左轮速度占用几位
            //从传感器中得到点击编码器的数值,并赋值给car_leftwheel_motor_w,和car_rightwheel_motor_w.这个值代表的是电机的转速,并不是轮胎的



            for (int i = 0; i < receivenumber; i++)
            {
                // ROS_INFO("buffer中的第%d个数据是%c:",i,buffer[i+1]);
                //获取到了":"这个数据,根据这个来获得数据
                if (buffer[i] == 0x3a )
                {
                    
                    //计算:右边有几个数据,这个数据代表的是左轮转速
                    for (int j = 1; j <= 4; j++) //最多四位
                    {
                        if (buffer[i + j] == 0x0d)
                        {
                            break;
                        }
                        //0x2d为考虑负数的情况,0x30-0x39即为0-9
                        else if ( (buffer[i + j] >= 0x30 && buffer[i + j] <= 0x39) || buffer[i + j] == 0x2d) 
                        {
                            left_velocityBit++;
                        }
                    }

                    // //计算:左边有几个数据,这个数据代表的是右轮转速
                    for (int j = 1; j <= 4; j++) //最多四位
                    {
                        if (buffer[i - j] == 0x3d)
                        {
                            break;
                        }
                        else if ((buffer[i - j] >= 0x30 && buffer[i - j] <= 0x39) || buffer[i - j] == 0x2d)
                        {
                            right_velocityBit++;
                        }
                    }

                    // ROS_INFO("左边有%d个数,右边有几个数%d",left_velocityBit,right_velocityBit);

                    // //解算左轮角速度:注意要把字符转换成对应数字在计算,-0x30代表转换为10进制
                    if (buffer[i + 1] == 0x2d) //如果是负数
                    {
                        // ROS_INFO("内部测试:%d", left_velocityBit);
                        if (left_velocityBit == 2)
                        {
                            car_leftwheel_motor_w = -1 * (buffer[i + 2] - 0x30);
                        }
                        else if (left_velocityBit == 3)
                        {
                            car_leftwheel_motor_w = -1 * (10 * (buffer[i + 2] - 0x30) + (buffer[i + 3] - 0x30));
                        }
                        else if (left_velocityBit == 4)
                        {
                            // ROS_INFO("***********计算看看***********:%d", 100 * (buffer[i + 2] - 0x30));
                            car_leftwheel_motor_w = -1 * (100 * (buffer[i + 2] - 0x30) + 10 * (buffer[i + 3] - 0x30) + (buffer[i + 4] - 0x30));
                        }
                        else
                        {
                            ROS_INFO_STREAM("速度太快了");
                        }
                    }
                    else //正数读取
                    {
                        if (left_velocityBit == 1)
                        {
                            car_leftwheel_motor_w = (buffer[i + 1] - 0x30);
                        }
                        else if (left_velocityBit == 2)
                        {
                            car_leftwheel_motor_w = 10 * (buffer[i + 1] - 0x30) + (buffer[i + 2] - 0x30);
                        }
                        else if (left_velocityBit == 3)
                        {
                            car_leftwheel_motor_w = 100 * (buffer[i + 1] - 0x30) + 10 * (buffer[i + 2] - 0x30) + (buffer[i + 3] - 0x30);
                        }
                        else
                        {
                            ROS_INFO_STREAM("速度太快了");
                        }
                    }

                    // ROS_INFO("****内部测试*****:%d", right_velocityBit);
                    // 解算右轮角速度:注意要把字符转换成对应数字在计算,-0x30代表转换为10进制;右轮在:左边的数据
                    if (buffer[i - right_velocityBit] == 0x2d) //如果是负数
                    {
                       if(right_velocityBit == 2)
                       {
                           car_rightwheel_motor_w = -1 * (buffer[i - right_velocityBit+1]-0x30);
                       }
                       else if(right_velocityBit == 3)
                       {
                           car_rightwheel_motor_w = -1 * (10 * (buffer[i - right_velocityBit + 1] - 0x30) + (buffer[i - right_velocityBit + 2] - 0x30));
                       }
                       else if(right_velocityBit == 4)
                       {
                           car_rightwheel_motor_w = -1 * (100 * (buffer[i - right_velocityBit + 1] - 0x30) + 10 * (buffer[i - right_velocityBit + 2] - 0x30) + (buffer[i - right_velocityBit + 3] - 0x30));
                       }
                       else
                       {
                           ROS_INFO_STREAM("速度太快了");
                       }
                    }
                    else  //读取正数
                    {
                        if (right_velocityBit == 1)
                        {
                            car_rightwheel_motor_w =  (buffer[i -right_velocityBit] - 0x30);
                        }
                        else if (right_velocityBit == 2)
                        {
                            car_rightwheel_motor_w = 10 * (buffer[i -right_velocityBit] - 0x30) + (buffer[i-right_velocityBit+1] - 0x30);
                        }
                        else if (right_velocityBit == 3)
                        {
                            // ROS_INFO("i的值是:%d****************%c**********************",i,(buffer[i-1]));
                            car_rightwheel_motor_w = 100 * (buffer[i - right_velocityBit] - 0x30) + 10 * (buffer[i - right_velocityBit + 1] - 0x30) + (buffer[i - right_velocityBit + 2] - 0x30);
                        }
                        else
                        {
                            ROS_INFO_STREAM("速度太快了");
                        }
                    }

                    car_leftwheel_velocity = -1.0 *car_leftwheel_motor_w / 24 * 0.1047 * 0.18;
                    car_rightwheel_velocity = 1.0* car_rightwheel_motor_w / 24 * 0.1047 * 0.18;

                    // ROS_INFO("左边的数据分别是:%c,%c,%c,%c", buffer[i -4 ], buffer[i - 3], buffer[i - 2], buffer[i - 1]);
                    // ROS_INFO("右边的数据分别是:%c,%c,%c,%c", buffer[i +1 ], buffer[i + 2], buffer[i +3 ], buffer[i + 4]);
                    // ROS_INFO("car left motor_w:%f;", car_leftwheel_motor_w * 2 * 3.14 / 24/6 * 0.18); //正数是反转
                    // ROS_INFO("car right motor_w:%f;", car_rightwheel_motor_w * 2 * 3.14 /24/6 * 0.18);

                    // ROS_INFO("左轮子转速:%f;    ", car_leftwheel_velocity); //正数是反转
                    // ROS_INFO("右轮子转速:%f;", car_rightwheel_velocity );
                    //  ROS_INFO("左边有%d个数据", right_velocityBit/24);
                    //  ROS_INFO("右边有%d个数据", left_velocityBit/24);
                }
            }
        }

        else
        {
            car_leftwheel_velocity = 0;
            car_rightwheel_velocity = 0;
        }

        VelocityCar.VelocityCar = (car_leftwheel_velocity + car_rightwheel_velocity) / 2;

        // ROS_INFO("车子的左轮速度是:%f",car_leftwheel_velocity);
        // ROS_INFO("车子的右轮速度是:%f",car_rightwheel_velocity);
        // ROS_INFO("车子的速度是:%f",VelocityCar.VelocityCar);

        VelocityCar.VelocityCar_w = (car_leftwheel_velocity - car_rightwheel_velocity) / CarCrossDistance ;
        // VelocityCar.VelocityCar_x = VelocityCar.VelocityCar;

        
        ros::spinOnce();
        loop_rate.sleep(); //等待设定时间到达
        odom_publisher.publish(VelocityCar);

    }
}