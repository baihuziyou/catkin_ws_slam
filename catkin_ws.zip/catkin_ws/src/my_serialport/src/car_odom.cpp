#include <ros/ros.h>
#include <serial/serial.h>
#include <std_msgs/String.h>
#include <geometry_msgs/Twist.h> //cmd_vel在这个库文件里面
#include <std_msgs/Empty.h>
#include <sstream>
#include <nav_msgs/Odometry.h>
#include <tf/transform_broadcaster.h>  //从Z轴转角到四元数函数需要头文件
#include "tf2_ros/transform_broadcaster.h"  //发布动态的坐标关系。
#include <math.h>
#include <ImuCar.h>
#include <VelocityCar.h>

/*

*/



#define WheelRadios 0.18
#define CarCrossDistance 1.440

serial::Serial serialport_odom; //定义自己的串口

//几个宏定义,CarCrossDistance:两个轮胎之间的距离,车宽度; WheelRadios:车轮半径
//导航需要的数据odemetry

nav_msgs::Odometry car_odom;

ros::Time current_time, last_time;

geometry_msgs::TransformStamped tf_odom2baselink;

geometry_msgs::Quaternion QuanterionFromYaw;

void odomCallback(const my_serialport::VelocityCar::ConstPtr& msg)
{
    // 根据频率计算时间间隔
    current_time = ros::Time::now();
    double delta_t = (current_time - last_time).toSec();
    last_time = ros::Time::now();
    // ROS_INFO("%f", delta_t);

    car_odom.twist.twist.linear.x =  msg->VelocityCar_w;
    car_odom.twist.twist.linear.y =  msg->VelocityCar_y;
    car_odom.twist.twist.angular.z = msg->VelocityCar_w;

    QuanterionFromYaw = tf::createQuaternionMsgFromYaw(msg->CarYaw * 0.01745);   //从偏航角到四元数
    car_odom.pose.pose.orientation.w = QuanterionFromYaw.w;
    car_odom.pose.pose.orientation.x = QuanterionFromYaw.x;
    car_odom.pose.pose.orientation.y = QuanterionFromYaw.y;
    car_odom.pose.pose.orientation.z = QuanterionFromYaw.z;

    // car_odom.pose.pose.orientation.w = msg->QuaternionCar_w;
    // car_odom.pose.pose.orientation.x = msg->QuaternionCar_x;
    // car_odom.pose.pose.orientation.y = msg->QuaternionCar_y;
    // car_odom.pose.pose.orientation.z = msg->QuaternionCar_z;

    car_odom.pose.pose.position.x += delta_t * msg->VelocityCar_x;
    car_odom.pose.pose.position.y += delta_t * msg->VelocityCar_y;

    tf_odom2baselink.transform.translation.x = car_odom.pose.pose.position.x;
    tf_odom2baselink.transform.translation.y = car_odom.pose.pose.position.y;

    tf_odom2baselink.transform.rotation.w = QuanterionFromYaw.w;
    tf_odom2baselink.transform.rotation.x = QuanterionFromYaw.x;
    tf_odom2baselink.transform.rotation.y = QuanterionFromYaw.y;
    tf_odom2baselink.transform.rotation.z = QuanterionFromYaw.z;
}

int main(int argc, char **argv)
{
    setlocale(LC_CTYPE, "zh_CN.utf8"); //中文不乱码

    //初始化节点
    ros::init(argc, argv, "car_odom_node");
    //声明节点句柄
    ros::NodeHandle nh;
    //发布话题
    ros::Publisher car_odom_publisher = nh.advertise<nav_msgs::Odometry>("odom", 100);
    //订阅话题
    ros::Subscriber car_odom_subscriber = nh.subscribe("TopicVelocity", 1000, odomCallback);
    // 设置发布话题频率
    ros::Rate loop_rate(10); //不是时间，是频率,代表1秒5次的速度发布或者调用回调函数，5hz

    tf::TransformBroadcaster car_odom_broadcaster;

    // 定义两个时间,这两个时间间隔用来计算里程计相关参数
    current_time = ros::Time::now();
    last_time = ros::Time::now();


    while (ros::ok())
    {

        car_odom.header.frame_id = "odom";
        car_odom.child_frame_id = "Base_Link";
        // car_odom.header.seq = ;
        // car_odom.header.stamp = ros::Time::now();

        tf_odom2baselink.child_frame_id = "Base_Link";
        tf_odom2baselink.header.frame_id = "odom";
        // tf_odom2baselink.header.stamp = ros::Time::now();
        ros::spinOnce();
        
        car_odom.header.stamp = ros::Time::now();
        tf_odom2baselink.header.stamp = ros::Time::now();
        car_odom_publisher.publish(car_odom);
        car_odom_broadcaster.sendTransform(tf_odom2baselink);

        loop_rate.sleep(); //等待设定时间到达

    }
}