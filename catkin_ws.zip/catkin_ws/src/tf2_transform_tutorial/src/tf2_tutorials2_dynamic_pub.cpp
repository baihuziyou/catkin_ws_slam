#include "ros/ros.h"
#include "turtlesim/Pose.h"                 //要订阅乌龟的位置姿态，所以需要包含这个头文件。
#include "tf2_ros/transform_broadcaster.h"  //发布动态的坐标关系。
#include "geometry_msgs/TransformStamped.h" //TransformStamped 这个是tf发布的消息类型所需要的头文件
#include "tf2/LinearMath/Quaternion.h"      //欧拉角与四元数之间转换
/*
 1.订阅乌龟的位置和姿态信息
 2.初始化，设置编码
 3.创建一个订阅对象，订阅乌龟的/turtle1/pose;
 4.回调函数中处理订阅的消息，并将位置和姿态信息转换成相对坐标发布出去。
 5.spin（）
*/

// 4.回调函数中处理订阅的消息，并将位置和姿态信息转换成相对坐标发布出去。
void poseCallback(const turtlesim::Pose::ConstPtr &pose) //这个消息类型就是turtlesim/pose类型的数据
{
    // a 创建发布对象,使用static关键字，防止每次进入回调函数都重新生成一个pub
    static tf2_ros::TransformBroadcaster pub;

    // b 组织被发布的数据
    geometry_msgs::TransformStamped ts;
    // header
    ts.header.frame_id = "world";
    ts.header.stamp = ros::Time::now();
    // frame_id
    ts.child_frame_id = "turtl1e";
    // translation
    ts.transform.translation.x = pose->x;
    ts.transform.translation.y = pose->y;
    ts.transform.translation.z = 0; //乌龟没有z，直接设置为0
    // rotationg
    tf2::Quaternion qtn; //设置一个四元数，
    qtn.setRPY(0, 0, pose->theta);
    ts.transform.rotation.x = qtn.getX();
    ts.transform.rotation.y = qtn.getY();
    ts.transform.rotation.x = qtn.getZ();
    ts.transform.rotation.w = qtn.getW();


    // c 发布数据
    pub.sendTransform(ts);
}

int main(int argc, char *argv[])
{
    // 2.初始化，设置编码

    setlocale(LC_ALL, "");
    ros::init(argc, argv, "tf2_tutorials2_dynamic_pub");
    ros::NodeHandle n;

    // 3.创建一个订阅对象，订阅乌龟的/turtle1/pose;
    ros::Subscriber sub = n.subscribe("turtle1/pose", 100, poseCallback);

    // 5.spin（）
    ros::spin();

    return 0;
}