#include <ros/ros.h>
#include <tf/transform_broadcaster.h>      //tf用于广播数据的头文件

std::string turtle_name;

int main(int argc, char ** argv)
{
    ros::init(argc, argv, "tf_brodcaster");

    static tf::TransformBroadcaster tf_brd;    //用于广播tf坐标，

    geometry_msgs::TransformStamped my_transformstamp;        //广播需要的数据类型，包含了时间戳，父类，子类相关的。

/* 
//这个是std_msgs/TransformStamp包含的内容
    std_msgs/Header header
        uint32 seq
        time stamp
        string frame_id

    string child_frame_id

    geometry_msgs/Transform transform
        geometry_msgs/Vector3 translation
            float64 x
            float64 y
            float64 z
         geometry_msgs/Quaternion rotation  //四元数，但是一般无法得到，所以定义一个tf::Quaternion变量给他，但是这个类型的变量可以通过SETRPY设置欧拉角来自动转换
            float64 x
            float64 y
            float64 z
            float64 w
*/

    //设定header相关的数据
    my_transformstamp.header.seq = 100;
    my_transformstamp.header.stamp = ros::Time::now();
    my_transformstamp.header.frame_id = "base_axis";

    //设定子坐标系
    my_transformstamp.child_frame_id = "laser_axis";
    
    //设定xyz的值
    my_transformstamp.transform.translation.x = 1;
    my_transformstamp.transform.translation.y = 1;
    my_transformstamp.transform.translation.z = 1;


    tf::Quaternion my_orientation;   //存放姿态的变量。四元数，可以通过setRPY，这个变量可以直接进行矩阵变换。
    my_orientation.setRPY(0, 0, 1);

    //通过getXYZW获取对应的四元数值，存放到geometry_msgs/TransformStamp类型的数据中，因为ros中的tf需要这样类型的数据
    my_transformstamp.transform.rotation.x = my_orientation.getX();
    my_transformstamp.transform.rotation.y = my_orientation.getY();
    my_transformstamp.transform.rotation.z = my_orientation.getZ();
    my_transformstamp.transform.rotation.w = my_orientation.getW();

    ros::Rate loop_rate(1); //设置发布频率,不是时间，1秒1次的速度发布或者调用回调函数，50hz

    while (ros::ok())
    {
        tf_brd.sendTransform(my_transformstamp);
        ros::spinOnce();
        loop_rate.sleep();
    }
    return 0;
}